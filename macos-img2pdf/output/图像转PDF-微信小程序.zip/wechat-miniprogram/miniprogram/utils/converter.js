const { createPdf } = require('./pdf');

/** 包装微信异步接口，保持原始错误信息。 */
function callWx(method, options = {}) {
  return new Promise((resolve, reject) => {
    wx[method]({ ...options, success: resolve, fail: reject });
  });
}

/** 等比例限制长边，不放大小图片。 */
function fitSize(width, height, limit = 2400) {
  if (!(width > 0 && height > 0 && limit > 0)) {
    throw new Error('无法读取图片尺寸');
  }
  const scale = Math.min(1, limit / Math.max(width, height));
  return { width: Math.max(1, Math.round(width * scale)), height: Math.max(1, Math.round(height * scale)) };
}

/** 使用 Canvas 解码图片、铺白底，并在本地写入单页 PDF。 */
async function convertImage(canvas, source, target) {
  const image = canvas.createImage();
  await new Promise((resolve, reject) => {
    image.onload = resolve;
    image.onerror = () => reject(new Error('无法解码图片，请改用 JPG 或 PNG'));
    image.src = source;
  });
  const { width, height } = fitSize(image.width, image.height);
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext('2d');
  context.fillStyle = '#ffffff';
  context.fillRect(0, 0, width, height);
  context.drawImage(image, 0, 0, width, height);
  const fileSystem = wx.getFileSystemManager();
  let tempPath;
  try {
    const exported = await callWx('canvasToTempFilePath', {
      canvas, x: 0, y: 0, width, height, destWidth: width, destHeight: height,
      fileType: 'jpg', quality: 0.92,
    });
    tempPath = exported.tempFilePath;
    const jpeg = fileSystem.readFileSync(tempPath);
    const pdf = createPdf(jpeg, width, height);
    fileSystem.writeFileSync(target, pdf);
    return { filePath: target, size: pdf.byteLength, width, height };
  } catch (error) {
    // 写入失败可能留下不完整文件，只清理由本次转换指定的新目标。
    try { fileSystem.unlinkSync(target); } catch (_) { /* 文件尚不存在时无需清理。 */ }
    throw error;
  } finally {
    if (tempPath) {
      try { fileSystem.unlinkSync(tempPath); } catch (_) { /* 临时图片由微信兜底管理。 */ }
    }
    canvas.width = 1;
    canvas.height = 1;
  }
}

module.exports = { callWx, fitSize, convertImage };
