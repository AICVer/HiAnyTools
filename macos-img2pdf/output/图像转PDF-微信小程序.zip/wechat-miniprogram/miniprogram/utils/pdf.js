/** 将 ASCII 字符串编码为字节，避免依赖小程序没有的 Buffer。 */
function asciiBytes(text) {
  return Uint8Array.from(text, (character) => character.charCodeAt(0));
}

/** 将 Canvas 导出的 RGB JPEG 封装成单页 PDF，页边与图片等比例。 */
function createPdf(jpeg, width, height) {
  const image = jpeg instanceof Uint8Array ? jpeg : new Uint8Array(jpeg);
  if (image.length < 4 || image[0] !== 255 || image[1] !== 216) {
    throw new Error('图片编码不是 JPEG');
  }
  if (![width, height].every((value) => Number.isInteger(value) && value > 0 && value <= 65535)) {
    throw new Error('图片尺寸无效');
  }
  const pageWidth = (width * 72 / 150).toFixed(2);
  const pageHeight = (height * 72 / 150).toFixed(2);
  const content = `q\n${pageWidth} 0 0 ${pageHeight} 0 0 cm\n/Im0 Do\nQ\n`;
  const parts = [];
  const offsets = [0];
  let length = 0;
  /** 追加字节并累计真实长度，供交叉引用表使用。 */
  function append(value) {
    const bytes = typeof value === 'string' ? asciiBytes(value) : value;
    parts.push(bytes);
    length += bytes.length;
  }
  /** 追加一个 PDF 对象，二进制图片流直接使用原始字节。 */
  function object(number, body, stream) {
    offsets[number] = length;
    append(`${number} 0 obj\n${body}`);
    if (stream) {
      append('\nstream\n');
      append(stream);
      append('\nendstream');
    }
    append('\nendobj\n');
  }
  append('%PDF-1.4\n');
  object(1, '<< /Type /Catalog /Pages 2 0 R >>');
  object(2, '<< /Type /Pages /Kids [3 0 R] /Count 1 >>');
  object(3, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pageWidth} ${pageHeight}] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>`);
  object(4, `<< /Type /XObject /Subtype /Image /Width ${width} /Height ${height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${image.length} >>`, image);
  object(5, `<< /Length ${content.length} >>`, asciiBytes(content));
  const xrefOffset = length;
  append('xref\n0 6\n0000000000 65535 f \n');
  for (const offset of offsets.slice(1)) {
    append(`${String(offset).padStart(10, '0')} 00000 n \n`);
  }
  append(`trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF\n`);
  const result = new Uint8Array(length);
  let cursor = 0;
  for (const part of parts) {
    result.set(part, cursor);
    cursor += part.length;
  }
  return result.buffer;
}

module.exports = { createPdf };
