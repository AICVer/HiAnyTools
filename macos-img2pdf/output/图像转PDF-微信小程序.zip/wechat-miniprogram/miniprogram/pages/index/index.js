const { callWx, convertImage } = require('../../utils/converter');

const storageKey = 'imagePdfResultsV1';
const maxImages = 9;

/** 将接口错误整理为用户可读的提示。 */
function errorText(error) {
  return error.message || error.errMsg || '处理失败，请重试';
}

Page({
  data: {
    items: [], busy: false, choosing: false, progress: 0,
    status: '每张图片，生成一份 PDF。', showPrivacy: false,
  },

  /** 初始化私有导出目录，恢复仍可读取的本地结果。 */
  onLoad() {
    this.exportDir = `${wx.env.USER_DATA_PATH}/image-pdf`;
    this.alive = true;
    this.sequence = 0;
    const fileSystem = wx.getFileSystemManager();
    try {
      try { fileSystem.accessSync(this.exportDir); } catch (_) { fileSystem.mkdirSync(this.exportDir, true); }
      const saved = wx.getStorageSync(storageKey) || [];
      const items = saved.filter((item) => {
        try { fileSystem.accessSync(item.filePath); return true; } catch (_) { return false; }
      });
      this.setData({ items });
    } catch (error) {
      this.setData({ status: `本地存储不可用：${errorText(error)}` });
    }
    this.privacyHandler = (resolve) => {
      this.resolvePrivacy = resolve;
      this.setData({ showPrivacy: true });
    };
    wx.onNeedPrivacyAuthorization(this.privacyHandler);
  },

  /** 页面退出时停止后续批次并替换引用当前页面的隐私监听。 */
  onUnload() {
    this.alive = false;
    // 微信使用覆盖式注册，无对应 off 接口；避免旧页面继续接收回调。
    wx.onNeedPrivacyAuthorization((resolve) => resolve({ event: 'disagree' }));
    if (this.resolvePrivacy) this.resolvePrivacy({ event: 'disagree' });
  },

  /** 获取真实 Canvas 节点，明确处理初始化失败。 */
  getCanvas() {
    return new Promise((resolve, reject) => {
      this.createSelectorQuery().select('#converterCanvas').fields({ node: true }).exec((result) => {
        if (result[0] && result[0].node) resolve(result[0].node);
        else reject(new Error('画布初始化失败，请重新进入小程序'));
      });
    });
  },

  /** 请求隐私授权后选择相册图片或拍照，最多保留九项。 */
  async chooseImages() {
    if (this.data.busy || this.data.choosing) return;
    const remaining = maxImages - this.data.items.length;
    if (remaining <= 0) {
      wx.showToast({ title: '最多 9 张，请先清空列表', icon: 'none' });
      return;
    }
    this.setData({ choosing: true });
    try {
      await callWx('requirePrivacyAuthorize');
      const result = await callWx('chooseMedia', {
        count: remaining, mediaType: ['image'], sourceType: ['album', 'camera'], sizeType: ['original'],
      });
      const items = result.tempFiles.map((file) => {
        this.sequence += 1;
        const id = `${Date.now()}-${this.sequence}`;
        return { id, source: file.tempFilePath, name: `图片-${id}.pdf`, status: 'pending', message: '等待转换' };
      });
      if (this.alive) this.setData({ items: [...this.data.items, ...items], progress: 0, status: '准备好了，点击开始转换。' });
    } catch (error) {
      if (!/cancel|disagree|deny/i.test(errorText(error))) {
        wx.showToast({ title: '选图失败，请检查微信授权', icon: 'none' });
      }
    } finally {
      if (this.alive) this.setData({ choosing: false });
    }
  },

  /** 将已生成的文件记录保存到本地，下次进入可继续预览。 */
  saveResults() {
    const saved = this.data.items.filter((item) => item.status === 'success').map((item) => ({ ...item, source: '' }));
    try { wx.setStorageSync(storageKey, saved); return true; }
    catch (_) { return false; }
  },

  /** 顺序转换待处理图片，失败后继续，并跳过已成功项目。 */
  async startConversion() {
    if (this.data.busy || this.data.choosing) return;
    const pending = this.data.items.filter((item) => item.status !== 'success');
    if (!pending.length) {
      wx.showToast({ title: '请先添加待转换图片', icon: 'none' });
      return;
    }
    this.setData({ busy: true, progress: 0 });
    let completed = 0;
    let recordsSaved = true;
    try {
      const canvas = await this.getCanvas();
      for (const item of pending) {
        if (!this.alive) break;
        this.setData({ status: `正在转换 ${completed + 1} / ${pending.length}` });
        let updated;
        try {
          const converted = await convertImage(canvas, item.source, `${this.exportDir}/${item.id}.pdf`);
          updated = { ...item, ...converted, status: 'success', message: `${Math.ceil(converted.size / 1024)} KB · 转换成功` };
        } catch (error) {
          updated = { ...item, status: 'failed', message: errorText(error) };
        }
        if (!this.alive) {
          if (updated.filePath) {
            try { wx.getFileSystemManager().unlinkSync(updated.filePath); }
            catch (_) { /* 页面退出时由微信本地存储兜底管理。 */ }
          }
          break;
        }
        completed += 1;
        this.setData({
          items: this.data.items.map((current) => current.id === item.id ? updated : current),
          progress: Math.round(completed / pending.length * 100),
        });
        recordsSaved = this.saveResults() && recordsSaved;
      }
      const failed = this.data.items.filter((item) => item.status === 'failed').length;
      if (this.alive) this.setData({ status: `处理完成：成功 ${this.data.items.filter((item) => item.status === 'success').length}，失败 ${failed}。${recordsSaved ? '' : '记录保存失败，请先预览或转发。'}` });
    } catch (error) {
      if (this.alive) this.setData({ status: errorText(error) });
    } finally {
      if (this.alive) this.setData({ busy: false });
    }
  },

  /** 打开指定 PDF，显示微信文档菜单供用户保存或转发。 */
  async previewPdf(event) {
    const item = this.data.items.find((current) => current.id === event.currentTarget.dataset.id);
    if (!item || !item.filePath) return;
    try { await callWx('openDocument', { filePath: item.filePath, fileType: 'pdf', showMenu: true }); }
    catch (_) { wx.showToast({ title: '预览失败，请尝试转发后打开', icon: 'none' }); }
  },

  /** 由用户主动选择接收人并确认转发指定 PDF。 */
  async sharePdf(event) {
    const item = this.data.items.find((current) => current.id === event.currentTarget.dataset.id);
    if (!item || !item.filePath) return;
    try { await callWx('shareFileMessage', { filePath: item.filePath, fileName: item.name }); }
    catch (error) {
      if (!/cancel/i.test(errorText(error))) wx.showToast({ title: '转发失败，请尝试预览菜单', icon: 'none' });
    }
  },

  /** 确认后删除本工具的本地结果，保留原始相册图片。 */
  async clearItems() {
    if (this.data.busy || this.data.choosing || !this.data.items.length) return;
    const decision = await callWx('showModal', { title: '清空列表？', content: '将删除本工具生成的本地 PDF，原始图片不受影响。请先保存或转发需要的文件。', confirmText: '清空' });
    if (!decision.confirm) return;
    const fileSystem = wx.getFileSystemManager();
    const retained = [];
    for (const item of this.data.items) {
      if (item.filePath) {
        try { fileSystem.unlinkSync(item.filePath); }
        catch (_) { retained.push(item); }
      }
    }
    this.setData({ items: retained, progress: 0, status: retained.length ? '部分文件清理失败，请重试。' : '每张图片，生成一份 PDF。' });
    this.saveResults();
  },

  /** 展示微信后台配置的隐私保护指引。 */
  async openPrivacy() {
    try { await callWx('openPrivacyContract'); }
    catch (_) { wx.showToast({ title: '请先在微信后台配置隐私指引', icon: 'none' }); }
  },

  /** 用户点击微信隐私同意按钮后继续被挂起的选图操作。 */
  agreePrivacy() {
    this.resolvePrivacy({ buttonId: 'agreePrivacy', event: 'agree' });
    this.resolvePrivacy = null;
    this.setData({ showPrivacy: false });
  },

  /** 拒绝隐私授权并关闭弹窗，不读取用户图片。 */
  rejectPrivacy() {
    this.resolvePrivacy({ event: 'disagree' });
    this.resolvePrivacy = null;
    this.setData({ showPrivacy: false });
  },
});
