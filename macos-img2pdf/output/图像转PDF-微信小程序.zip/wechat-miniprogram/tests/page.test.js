jest.mock('../miniprogram/utils/converter', () => ({ callWx: jest.fn(), convertImage: jest.fn() }));
const { callWx, convertImage } = require('../miniprogram/utils/converter');
let definition;
global.Page = (page) => { definition = page; };
require('../miniprogram/pages/index/index');

let page;
let fileSystem;
const event = (id) => ({ currentTarget: { dataset: { id } } });
const pending = (id) => ({ id, name: `${id}.pdf`, source: `/${id}.jpg`, status: 'pending' });
const success = (id) => ({ ...pending(id), filePath: `/local/image-pdf/${id}.pdf`, status: 'success' });

beforeEach(() => {
  jest.clearAllMocks();
  callWx.mockReset().mockResolvedValue({});
  convertImage.mockReset().mockResolvedValue({ filePath: '/out.pdf', size: 1200 });
  fileSystem = { accessSync: jest.fn(), mkdirSync: jest.fn(), unlinkSync: jest.fn() };
  global.wx = {
    env: { USER_DATA_PATH: '/local' }, getFileSystemManager: () => fileSystem,
    getStorageSync: jest.fn(() => []), setStorageSync: jest.fn(), showToast: jest.fn(),
    onNeedPrivacyAuthorization: jest.fn(),
  };
  page = { ...definition, data: structuredClone(definition.data) };
  page.setData = jest.fn((values) => Object.assign(page.data, values));
  page.onLoad();
  page.createSelectorQuery = () => {
    const query = { select: () => query, fields: () => query, exec: (callback) => callback([{ node: {} }]) };
    return query;
  };
});

test('创建目录并恢复有效记录，忽略已不存在的文件', () => {
  wx.getStorageSync.mockReturnValue([success('ok'), success('gone')]);
  fileSystem.accessSync.mockImplementation((path) => { if (path.endsWith('gone.pdf') || path === '/local/image-pdf') throw new Error('missing'); });
  page.onLoad();
  expect(fileSystem.mkdirSync).toHaveBeenCalledWith('/local/image-pdf', true);
  expect(page.data.items).toHaveLength(1);
});

test('本地存储不可用时给出说明', () => {
  wx.getStorageSync.mockImplementation(() => { throw new Error('storage failed'); });
  page.onLoad();
  expect(page.data.status).toContain('存储不可用');
});

test('隐私同意、拒绝、退出覆盖监听与合约打开', async () => {
  const resolve = jest.fn();
  page.privacyHandler(resolve);
  expect(page.data.showPrivacy).toBe(true);
  page.agreePrivacy();
  expect(resolve).toHaveBeenCalledWith({ buttonId: 'agreePrivacy', event: 'agree' });
  page.privacyHandler(resolve);
  page.rejectPrivacy();
  expect(page.data.showPrivacy).toBe(false);
  await page.openPrivacy();
  callWx.mockRejectedValueOnce(new Error('not configured'));
  await page.openPrivacy();
  expect(wx.showToast).toHaveBeenCalled();
  page.privacyHandler(resolve);
  page.onUnload();
  expect(resolve).toHaveBeenCalledWith({ event: 'disagree' });
  expect(page.alive).toBe(false);
  const fallback = wx.onNeedPrivacyAuthorization.mock.calls.at(-1)[0];
  fallback(resolve);
  expect(resolve).toHaveBeenLastCalledWith({ event: 'disagree' });
});

test('选图先授权，数量限制与重新进入的命名不冲突', async () => {
  callWx.mockResolvedValueOnce({}).mockResolvedValueOnce({ tempFiles: [{ tempFilePath: '/one.png' }, { tempFilePath: '/two.png' }] });
  await page.chooseImages();
  expect(callWx.mock.calls[0][0]).toBe('requirePrivacyAuthorize');
  expect(callWx.mock.calls[1][1].count).toBe(9);
  expect(page.data.items).toHaveLength(2);
  expect(page.data.items[0].id).not.toBe(page.data.items[1].id);
  expect(page.data.choosing).toBe(false);
  page.data.items = Array.from({ length: 9 }, (_, index) => pending(String(index)));
  await page.chooseImages();
  expect(wx.showToast).toHaveBeenCalledWith(expect.objectContaining({ title: expect.stringContaining('最多') }));
});

test.each([{ errMsg: 'choose:cancel' }, { message: 'disagree' }, {}, { errMsg: 'failed' }])('选图取消或失败后恢复按钮', async (error) => {
  callWx.mockRejectedValueOnce(error);
  await page.chooseImages();
  expect(page.data.choosing).toBe(false);
  expect(page.data.items).toEqual([]);
});

test('忙碌时不重入选图、转换或清空', async () => {
  page.data.busy = true;
  await page.chooseImages();
  await page.startConversion();
  await page.clearItems();
  page.data.busy = false;
  page.data.choosing = true;
  await page.chooseImages();
  await page.startConversion();
  await page.clearItems();
  expect(callWx).not.toHaveBeenCalled();
});

test('逐项转换、失败继续、已成功跳过，失败项可重试', async () => {
  page.data.items = [success('done'), pending('bad'), pending('good')];
  convertImage.mockRejectedValueOnce(new Error('broken'));
  await page.startConversion();
  expect(page.data.items.map((item) => item.status)).toEqual(['success', 'failed', 'success']);
  expect(page.data.progress).toBe(100);
  expect(page.data.busy).toBe(false);
  expect(page.data.status).toContain('成功 2，失败 1');
  expect(wx.setStorageSync).toHaveBeenLastCalledWith('imagePdfResultsV1', expect.arrayContaining([expect.objectContaining({ source: '' })]));
  await page.startConversion();
  expect(convertImage).toHaveBeenCalledTimes(3);
  await page.startConversion();
  expect(wx.showToast).toHaveBeenCalled();
});

test('画布初始化失败解除运行状态；未选择图片不运行', async () => {
  await page.startConversion();
  page.data.items = [pending('one')];
  page.createSelectorQuery = () => {
    const query = { select: () => query, fields: () => query, exec: (callback) => callback([]) };
    return query;
  };
  await page.startConversion();
  expect(page.data.status).toContain('画布初始化失败');
  expect(page.data.busy).toBe(false);
});

test('退出页面停止继续转换', async () => {
  page.data.items = [pending('one')];
  page.alive = false;
  await page.startConversion();
  expect(convertImage).not.toHaveBeenCalled();
  page.onUnload();
});

test('记录保存失败不被最终完成提示覆盖', async () => {
  wx.setStorageSync.mockImplementation(() => { throw new Error('quota'); });
  page.data.items = [pending('one')];
  await page.startConversion();
  expect(page.data.status).toContain('记录保存失败');
});

test('转换中离开页面不更新已卸载界面，并清理未交付输出', async () => {
  page.data.items = [pending('one'), pending('two')];
  convertImage.mockImplementationOnce(async () => {
    page.onUnload();
    page.setData.mockClear();
    return { filePath: '/unclaimed.pdf', size: 123 };
  });
  await page.startConversion();
  expect(page.setData).not.toHaveBeenCalled();
  expect(convertImage).toHaveBeenCalledTimes(1);
  expect(fileSystem.unlinkSync).toHaveBeenCalledWith('/unclaimed.pdf');
});

test('预览与转发使用本地路径，取消转发不报错', async () => {
  page.data.items = [success('one'), pending('two')];
  await page.previewPdf(event('one'));
  expect(callWx).toHaveBeenCalledWith('openDocument', expect.objectContaining({ fileType: 'pdf', showMenu: true }));
  await page.sharePdf(event('one'));
  expect(callWx).toHaveBeenCalledWith('shareFileMessage', expect.objectContaining({ fileName: 'one.pdf' }));
  await page.previewPdf(event('missing'));
  await page.previewPdf(event('two'));
  await page.sharePdf(event('missing'));
  await page.sharePdf(event('two'));
  callWx.mockRejectedValueOnce({ errMsg: 'cancel' });
  await page.sharePdf(event('one'));
  expect(wx.showToast).not.toHaveBeenCalled();
  callWx.mockRejectedValueOnce(new Error('failed'));
  await page.sharePdf(event('one'));
  callWx.mockRejectedValueOnce(new Error('failed'));
  await page.previewPdf(event('one'));
  expect(wx.showToast).toHaveBeenCalledTimes(2);
});

test('清空必须确认，删除失败保留记录，且不删除原图', async () => {
  await page.clearItems();
  page.data.items = [success('one'), pending('two')];
  callWx.mockResolvedValueOnce({ confirm: false });
  await page.clearItems();
  expect(fileSystem.unlinkSync).not.toHaveBeenCalled();
  callWx.mockResolvedValueOnce({ confirm: true });
  fileSystem.unlinkSync.mockImplementationOnce(() => { throw new Error('busy'); });
  await page.clearItems();
  expect(page.data.items).toHaveLength(1);
  expect(page.data.status).toContain('清理失败');
  callWx.mockResolvedValueOnce({ confirm: true });
  await page.clearItems();
  expect(page.data.items).toEqual([]);
  expect(fileSystem.unlinkSync).toHaveBeenCalledWith('/local/image-pdf/one.pdf');
});
