const { callWx, fitSize, convertImage } = require('../miniprogram/utils/converter');

let fileSystem;
let canvas;
let context;

beforeEach(() => {
  fileSystem = { readFileSync: jest.fn(() => new Uint8Array([255, 216, 255, 217]).buffer), writeFileSync: jest.fn(), unlinkSync: jest.fn() };
  context = { fillRect: jest.fn(), drawImage: jest.fn() };
  canvas = {
    createImage: () => ({ width: 4800, height: 3200, set src(value) { this.onload(); } }),
    getContext: jest.fn(() => context),
  };
  global.wx = {
    getFileSystemManager: () => fileSystem,
    canvasToTempFilePath: jest.fn((options) => options.success({ tempFilePath: '/temp.jpg' })),
  };
});

test('限制长边但不放大，极窄图片至少一个像素', () => {
  expect(fitSize(4800, 3200)).toEqual({ width: 2400, height: 1600 });
  expect(fitSize(3200, 4800)).toEqual({ width: 1600, height: 2400 });
  expect(fitSize(200, 100)).toEqual({ width: 200, height: 100 });
  expect(fitSize(1, 10000)).toEqual({ width: 1, height: 2400 });
});

test.each([[0, 2], [2, 0], [2, 3, 0]])('无效尺寸不能转换', (...size) => {
  expect(() => fitSize(...size)).toThrow();
});

test('铺白底、指定 JPEG 质量、写出 PDF 并释放临时文件和画布', async () => {
  const result = await convertImage(canvas, '/input.png', '/out.pdf');
  expect(result.width).toBe(2400);
  expect(result.height).toBe(1600);
  expect(context.fillStyle).toBe('#ffffff');
  expect(context.fillRect).toHaveBeenCalledWith(0, 0, 2400, 1600);
  expect(wx.canvasToTempFilePath).toHaveBeenCalledWith(expect.objectContaining({ fileType: 'jpg', quality: 0.92, destWidth: 2400 }));
  expect(fileSystem.writeFileSync).toHaveBeenCalledWith('/out.pdf', expect.any(ArrayBuffer));
  expect(fileSystem.unlinkSync).toHaveBeenCalledWith('/temp.jpg');
  expect(canvas.width).toBe(1);
  expect(canvas.height).toBe(1);
});

test('解码失败返回可读错误', async () => {
  canvas.createImage = () => ({ set src(value) { this.onerror(); } });
  await expect(convertImage(canvas, '/bad', '/out.pdf')).rejects.toThrow('无法解码');
  expect(fileSystem.writeFileSync).not.toHaveBeenCalled();
});

test('写入失败清理半成品，清理失败也保留原始错误', async () => {
  fileSystem.writeFileSync.mockImplementation(() => { throw new Error('quota'); });
  fileSystem.unlinkSync.mockImplementation(() => { throw new Error('cleanup'); });
  await expect(convertImage(canvas, '/input', '/out.pdf')).rejects.toThrow('quota');
  expect(fileSystem.unlinkSync).toHaveBeenCalledWith('/out.pdf');
  expect(canvas.width).toBe(1);
});

test('Canvas 导出失败时不读取不存在的临时文件', async () => {
  wx.canvasToTempFilePath = (options) => options.fail({ errMsg: 'canvas failed' });
  await expect(convertImage(canvas, '/input', '/out.pdf')).rejects.toEqual({ errMsg: 'canvas failed' });
  expect(fileSystem.readFileSync).not.toHaveBeenCalled();
});

test('微信异步包装保留成功结果', async () => {
  wx.testApi = (options) => options.success(3);
  await expect(callWx('testApi')).resolves.toBe(3);
});
