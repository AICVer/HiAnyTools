const { createPdf } = require('../miniprogram/utils/pdf');

test('生成正确的 PDF 对象、字节偏移和未改写的图片流', () => {
  const jpeg = new Uint8Array([255, 216, 0, 128, 254, 255, 217]);
  const result = createPdf(jpeg, 1200, 800);
  const text = Buffer.from(result).toString('latin1');
  expect(text.startsWith('%PDF-1.4')).toBe(true);
  expect(text).toContain('/MediaBox [0 0 576.00 384.00]');
  expect(text).toContain('/Length 7');
  expect(Buffer.from(result).includes(Buffer.from(jpeg))).toBe(true);
  const offset = Number(text.match(/startxref\n(\d+)/)[1]);
  expect(text.slice(offset, offset + 4)).toBe('xref');
  const entries = text.slice(offset).split('\n').slice(3, 8);
  entries.forEach((entry, index) => {
    expect(text.slice(Number(entry.slice(0, 10)))).toMatch(new RegExp(`^${index + 1} 0 obj`));
  });
  expect(createPdf(jpeg.buffer, 1200, 800)).toEqual(result);
});

test.each([new Uint8Array(), new Uint8Array([255, 0, 1, 2])])('拒绝非 JPEG 输入', (bytes) => {
  expect(() => createPdf(bytes, 20, 30)).toThrow('不是 JPEG');
});

test.each([[0, 2], [2, -1], [1.5, 2], [65536, 2], [NaN, 20]])('拒绝无效尺寸 %s %s', (width, height) => {
  expect(() => createPdf(new Uint8Array([255, 216, 255, 217]), width, height)).toThrow('尺寸无效');
});
