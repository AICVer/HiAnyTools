# 图像转 PDF · 微信小程序

原生微信小程序首版。沿用已确认的「每张图片分别生成一个 PDF」方式，新增小程序工程，不依赖桌面版 Python，不使用服务器或云开发。

## 导入与运行

1. 在微信开发者工具中选择「导入项目」。
2. 项目目录选择本 README 所在的 `wechat-miniprogram` 文件夹，不是里面的 `miniprogram` 子文件夹。
3. 将 `project.config.json` 的 `appid` 替换为你自己的小程序 AppID；当前 `touristappid` 仅作导入占位。游客模式不作为选图、隐私授权和分享可用性的验收依据。
4. 选择普通「小程序」项目，不启用云开发；调试基础库选择 **2.32.3 或以上**。运行部分没有 npm 依赖，不需要「构建 npm」。
5. 在对应微信小程序后台配置用户隐私保护指引，准确说明读取用户所选图片用于本地 PDF 转换，再在开发者工具与手机上检查授权流程。
6. 编译后点击「从相册选择 / 拍照」，再点击「开始转换」。生成后可预览 PDF，或点击「转发 PDF」由用户选择接收人并确认。

目前未安装微信开发者工具、未提供实际 AppID，因此尚未进行小程序编译及真机预览。这里交付的是已完成本地单元测试和独立 PDF 回读验证的源代码，不代表已经上线。

## 已实现

- 一次最多保留 9 张图片或已转换结果，可相册多选或拍照。
- 每张图片单独导出单页 PDF，不合并；移动端不提供桌面文件夹选择。
- 所有图片通过微信 Canvas 解码，铺白底、保持比例，长边最多 2400 像素，不放大小图。
- Canvas 以 JPEG 质量 0.92 编码，PDF 按 150 DPI 定义页面尺寸，不强制 A4；这不是原图无损归档。
- 逐张处理与进度显示；单张失败继续，重新开始时只处理未成功项目。
- 结果保存在小程序本地私有目录，下次进入仍可预览；照片临时路径不写入结果记录。
- 输出采用唯一文件名，避免同名覆盖。微信选图接口通常不给出相册原始文件名，因此使用「图片-唯一编号.pdf」。
- 清空前确认，仅删除本工具生成的 PDF，不修改或删除相册原图。
- 隐私授权弹窗提供指引链接及同意/拒绝操作；用户未同意时不继续选图。
- 页面退出后停止后续转换，并清理尚未交付的当前输出。

## 处理流程

`微信选图 → Canvas 解码/铺白底/等比例缩小 → JPEG → 本地 JavaScript PDF 封装 → 本地文件 → 预览/手动转发`

运行代码没有 `wx.request`、`wx.uploadFile` 或云开发调用。转发 PDF 会通过微信发送，仅在用户主动点击并确认接收人后发生。

## 测试与证据

测试开发依赖为 Jest 30.4.2，已经安装在此工程本机的 `node_modules`；分发源码包不包含依赖目录。恢复测试依赖可运行 `npm ci --ignore-scripts`，再执行：

```sh
npm test
```

最终结果：**33 项 Jest 测试通过，语句/函数/行覆盖率 100%，分支覆盖率 94.62%**。范围包括 `utils/pdf.js`、`utils/converter.js` 和页面逻辑；微信 API、Canvas 解码及页面 `setData` 在 Jest 中使用模拟实现。

项目根目录的独立回读测试：

```sh
/Users/wangshupeng/miniforge3/bin/conda run --no-capture-output -n base python -m pytest tests/test_wechat_pdf.py -q
```

**3 项 pytest 通过**：真实 Node 执行小程序 PDF 编码器生成横图、竖图、方图 PDF；PyMuPDF 独立验证无修复、单页、尺寸比例、JPEG 字节不变及渲染像素误差。测试不依赖相册素材，也不上传数据。

详细报告位于项目根目录 `docs/tests/report-test7.txt` 至 `report-test12.txt`；test12 为最终 Jest 复测，test11 为独立 pytest 回读。覆盖率与渲染检查位于 `output/wechat/`。这些报告和输出文件不打包进小程序。

## 尚未验证及首版限制

- 尚未在微信开发者工具编译 WXML/WXSS，也未在 iOS/Android 微信真机运行；本机缺少开发者工具和实际 AppID。
- 相册/相机授权弹窗、系统文件预览、转发文件操作、真实 Canvas 内存占用和照片 EXIF 方向，需要用自己的 AppID 在手机上验收。单元测试不证明这些平台行为已经通过。
- 建议首轮用普通 JPG、PNG 测试；HEIC、动态图片、特殊 ICC/HDR、超大图片不作为首版保证范围。
- 未实现 OCR、多图合并、A4 排版或文件夹批处理。
- 本地 PDF 占用微信小程序存储空间；导出需要的文件后可清空。退出前请等待转换结束；不要把小程序缓存视作长期备份。
- npm 安装过程提示 Jest 间接依赖的弃用信息；依赖仅用于本地测试，不进入小程序运行代码。

## 文件与接口依据

- `project.config.json`：开发者工具导入配置。
- `miniprogram/pages/index/`：页面、授权与批量处理流程。
- `miniprogram/utils/converter.js`：Canvas 和本地文件读写。
- `miniprogram/utils/pdf.js`：无运行时依赖的单页 PDF 编码器，仅接收 Canvas 生成的 RGB JPEG。
- `tests/`：Jest 测试。

接口参数核对依据为微信官方 [API 类型定义](https://github.com/wechat-miniprogram/api-typings/blob/master/types/wx/lib.wx.api.d.ts)，已核对选图数量、Canvas JPEG 导出、隐私授权回调以及本地文件分享参数。官方文档入口：[选择媒体](https://developers.weixin.qq.com/miniprogram/dev/api/media/video/wx.chooseMedia.html)、[Canvas 导出](https://developers.weixin.qq.com/miniprogram/dev/api/canvas/wx.canvasToTempFilePath.html)、[隐私授权](https://developers.weixin.qq.com/miniprogram/dev/api/open-api/privacy/wx.requirePrivacyAuthorize.html)、[预览文档](https://developers.weixin.qq.com/miniprogram/dev/api/file/wx.openDocument.html)、[转发文件](https://developers.weixin.qq.com/miniprogram/dev/api/share/wx.shareFileMessage.html)。
